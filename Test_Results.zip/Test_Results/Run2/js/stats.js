var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "83676",
        "ok": "65461",
        "ko": "18215"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "5"
    },
    "maxResponseTime": {
        "total": "11708",
        "ok": "11708",
        "ko": "10445"
    },
    "meanResponseTime": {
        "total": "480",
        "ok": "471",
        "ko": "512"
    },
    "standardDeviation": {
        "total": "1611",
        "ok": "1457",
        "ko": "2072"
    },
    "percentiles1": {
        "total": "31",
        "ok": "64",
        "ko": "11"
    },
    "percentiles2": {
        "total": "229",
        "ok": "295",
        "ko": "23"
    },
    "percentiles3": {
        "total": "2287",
        "ok": "2273",
        "ko": "8096"
    },
    "percentiles4": {
        "total": "10018",
        "ok": "9381",
        "ko": "10023"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 59500,
    "percentage": 71
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1743,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 4218,
    "percentage": 5
},
    "group4": {
    "name": "failed",
    "count": 18215,
    "percentage": 22
},
    "meanNumberOfRequestsPerSecond": {
        "total": "116.217",
        "ok": "90.918",
        "ko": "25.299"
    }
},
contents: {
"req_post-createuser-491f6": {
        type: "REQUEST",
        name: "post_createUser",
path: "post_createUser",
pathFormatted: "req_post-createuser-491f6",
stats: {
    "name": "post_createUser",
    "numberOfRequests": {
        "total": "53567",
        "ok": "42947",
        "ko": "10620"
    },
    "minResponseTime": {
        "total": "4",
        "ok": "4",
        "ko": "5"
    },
    "maxResponseTime": {
        "total": "11708",
        "ok": "11708",
        "ko": "10445"
    },
    "meanResponseTime": {
        "total": "447",
        "ok": "433",
        "ko": "504"
    },
    "standardDeviation": {
        "total": "1544",
        "ok": "1389",
        "ko": "2055"
    },
    "percentiles1": {
        "total": "26",
        "ok": "48",
        "ko": "11"
    },
    "percentiles2": {
        "total": "202",
        "ok": "255",
        "ko": "23"
    },
    "percentiles3": {
        "total": "1906",
        "ok": "1937",
        "ko": "1518"
    },
    "percentiles4": {
        "total": "10014",
        "ok": "8903",
        "ko": "10025"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 39283,
    "percentage": 73
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1032,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2632,
    "percentage": 5
},
    "group4": {
    "name": "failed",
    "count": 10620,
    "percentage": 20
},
    "meanNumberOfRequestsPerSecond": {
        "total": "74.399",
        "ok": "59.649",
        "ko": "14.75"
    }
}
    },"req_get-userbyid-a61e0": {
        type: "REQUEST",
        name: "get_userById",
path: "get_userById",
pathFormatted: "req_get-userbyid-a61e0",
stats: {
    "name": "get_userById",
    "numberOfRequests": {
        "total": "30109",
        "ok": "22514",
        "ko": "7595"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "2",
        "ko": "5"
    },
    "maxResponseTime": {
        "total": "11486",
        "ok": "11486",
        "ko": "10403"
    },
    "meanResponseTime": {
        "total": "539",
        "ok": "544",
        "ko": "524"
    },
    "standardDeviation": {
        "total": "1723",
        "ok": "1578",
        "ko": "2096"
    },
    "percentiles1": {
        "total": "46",
        "ok": "108",
        "ko": "11"
    },
    "percentiles2": {
        "total": "276",
        "ok": "356",
        "ko": "22"
    },
    "percentiles3": {
        "total": "3218",
        "ok": "3171",
        "ko": "8129"
    },
    "percentiles4": {
        "total": "10043",
        "ok": "10161",
        "ko": "10021"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 20217,
    "percentage": 67
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 711,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1586,
    "percentage": 5
},
    "group4": {
    "name": "failed",
    "count": 7595,
    "percentage": 25
},
    "meanNumberOfRequestsPerSecond": {
        "total": "41.818",
        "ok": "31.269",
        "ko": "10.549"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
