var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "74884",
        "ok": "18353",
        "ko": "56531"
    },
    "minResponseTime": {
        "total": "2",
        "ok": "3",
        "ko": "2"
    },
    "maxResponseTime": {
        "total": "60034",
        "ok": "31658",
        "ko": "60034"
    },
    "meanResponseTime": {
        "total": "16797",
        "ok": "6609",
        "ko": "20104"
    },
    "standardDeviation": {
        "total": "7704",
        "ok": "9673",
        "ko": "1903"
    },
    "percentiles1": {
        "total": "20006",
        "ok": "881",
        "ko": "20007"
    },
    "percentiles2": {
        "total": "20010",
        "ok": "11299",
        "ko": "20010"
    },
    "percentiles3": {
        "total": "20088",
        "ok": "28378",
        "ko": "20056"
    },
    "percentiles4": {
        "total": "29001",
        "ok": "31332",
        "ko": "20133"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 8881,
    "percentage": 12
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1086,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 8386,
    "percentage": 11
},
    "group4": {
    "name": "failed",
    "count": 56531,
    "percentage": 75
},
    "meanNumberOfRequestsPerSecond": {
        "total": "107.747",
        "ok": "26.407",
        "ko": "81.34"
    }
},
contents: {
"req_post-createuser-491f6": {
        type: "REQUEST",
        name: "post_createUser",
path: "post_createUser",
pathFormatted: "req_post-createuser-491f6",
stats: {
    "name": "post_createUser",
    "numberOfRequests": {
        "total": "60000",
        "ok": "14884",
        "ko": "45116"
    },
    "minResponseTime": {
        "total": "14",
        "ok": "19",
        "ko": "2"
    },
    "maxResponseTime": {
        "total": "60034",
        "ok": "31658",
        "ko": "60034"
    },
    "meanResponseTime": {
        "total": "16557",
        "ok": "5848",
        "ko": "20090"
    },
    "standardDeviation": {
        "total": "7837",
        "ok": "9265",
        "ko": "1747"
    },
    "percentiles1": {
        "total": "20006",
        "ok": "57",
        "ko": "20007"
    },
    "percentiles2": {
        "total": "20010",
        "ok": "8739",
        "ko": "20010"
    },
    "percentiles3": {
        "total": "20076",
        "ok": "27603",
        "ko": "20058"
    },
    "percentiles4": {
        "total": "28896",
        "ok": "31315",
        "ko": "20113"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 7874,
    "percentage": 13
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 859,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 6151,
    "percentage": 10
},
    "group4": {
    "name": "failed",
    "count": 45116,
    "percentage": 75
},
    "meanNumberOfRequestsPerSecond": {
        "total": "86.331",
        "ok": "21.416",
        "ko": "64.915"
    }
}
    },"req_get-userbyid-a61e0": {
        type: "REQUEST",
        name: "get_userById",
path: "get_userById",
pathFormatted: "req_get-userbyid-a61e0",
stats: {
    "name": "get_userById",
    "numberOfRequests": {
        "total": "14884",
        "ok": "3469",
        "ko": "11415"
    },
    "minResponseTime": {
        "total": "3",
        "ok": "3",
        "ko": "20000"
    },
    "maxResponseTime": {
        "total": "60010",
        "ok": "31605",
        "ko": "60010"
    },
    "meanResponseTime": {
        "total": "17764",
        "ok": "9874",
        "ko": "20161"
    },
    "standardDeviation": {
        "total": "7062",
        "ok": "10655",
        "ko": "2421"
    },
    "percentiles1": {
        "total": "20007",
        "ok": "5170",
        "ko": "20007"
    },
    "percentiles2": {
        "total": "20010",
        "ok": "18680",
        "ko": "20010"
    },
    "percentiles3": {
        "total": "22652",
        "ok": "29092",
        "ko": "20050"
    },
    "percentiles4": {
        "total": "31175",
        "ok": "31387",
        "ko": "20271"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 1007,
    "percentage": 7
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 227,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2235,
    "percentage": 15
},
    "group4": {
    "name": "failed",
    "count": 11415,
    "percentage": 77
},
    "meanNumberOfRequestsPerSecond": {
        "total": "21.416",
        "ok": "4.991",
        "ko": "16.424"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
